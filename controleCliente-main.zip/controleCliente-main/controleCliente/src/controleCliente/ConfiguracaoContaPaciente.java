package controleCliente;

import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/*cad = cadastro
 * edt = editar
 * pes = pesquisar
 * rem = remover
 * */

public class ConfiguracaoContaPaciente{
	
	
	public static void main(String[] args) {
		
		ArrayList<Paciente> listaPaciente = new ArrayList<Paciente>();
		
		
		//Label
		JLabel label = new JLabel("Controle de Pacientes");
		label.setFont(new Font("Calibri", Font.BOLD, 30));
		label.setForeground(Color.white);
		label.setBounds(200, 0, 300, 100);
		
		
		//Bot�es
		Button cad = new Button("Cadastro");
		cad.setBounds(20, 500, 150, 50);
		cad.setFont(new Font("Calibri", Font.BOLD, 20));
		
		JButton edt = new JButton("Editar");
		edt.setBounds(190, 500, 150, 50);
		edt.setFont(new Font("Calibri", Font.BOLD, 20));
		
		JButton pes = new JButton("Pesquisar");
		pes.setBounds(360, 500, 150, 50);
		pes.setFont(new Font("Calibri", Font.BOLD, 20));
		
		JButton rem = new JButton("Remover");
		rem.setBounds(530, 500, 150, 50);
		rem.setFont(new Font("Calibri", Font.BOLD, 20));
		
		
		// Janela
		JFrame janela = new JFrame("Controle de Pacientes");
		janela.setSize(700, 700);
		janela.getContentPane().setBackground(new Color(100, 50, 50));
		janela.add(label);
		janela.add(cad);
		janela.add(edt);
		janela.add(pes);
		janela.add(rem);
		janela.setLayout(null);
		janela.setVisible(true);
		
		//Comando do Bot�o Cadastro
		cad.addActionListener( new  ActionListener(){  
		    public void  actionPerformed(ActionEvent e){
		    	
		    	//Fecha a Janela antiga e cria uma nova
		    	janela.setVisible(false);
		    	JFrame pgcad = new JFrame("Controle de Pacientes");
				pgcad.setSize(700, 700);
				pgcad.getContentPane().setBackground(new Color(100, 50, 50));
				pgcad.setLayout(null);
				pgcad.setVisible(true);
				
				
				//criando usuario
				JTextField txtnome = new JTextField(30);
				JLabel labelNome = new JLabel("Nome: ");
				labelNome.setFont(new Font("Calibri", Font.BOLD, 30));
				labelNome.setForeground(Color.white);
				labelNome.setBounds(10, 50, 300, 30);
				txtnome.setBounds(250, 50, 300, 30);
				pgcad.add(txtnome);
				pgcad.add(labelNome);

				JTextField txtdate = new JTextField(30);
				JLabel labelDate = new JLabel("Data nascimento: ");
				labelDate.setFont(new Font("Calibri", Font.BOLD, 30));
				labelDate.setForeground(Color.white);
				labelDate.setBounds(10, 100, 300, 30);
				txtdate.setBounds(250, 100, 300, 30);
				pgcad.add(txtdate);
				pgcad.add(labelDate);

				
				JTextField txtendereco = new JTextField(30);
				JLabel labelEnd = new JLabel("Endereço: ");
				labelEnd.setFont(new Font("Calibri", Font.BOLD, 30));
				labelEnd.setForeground(Color.white);
				labelEnd.setBounds(10, 150, 300, 30);
				txtendereco.setBounds(250, 150, 300, 30);
				pgcad.add(txtendereco);
				pgcad.add(labelEnd);
				
				JTextField txtobservacao = new JTextField(30);
				JLabel labelObs = new JLabel("Observações: ");
				labelObs.setFont(new Font("Calibri", Font.BOLD, 30));
				labelObs.setForeground(Color.white);
				labelObs.setBounds(10, 200, 300, 30);
				txtobservacao.setBounds(250, 200, 300, 30);
				pgcad.add(txtobservacao);
				pgcad.add(labelObs);
				
				
				//Bot�es (Tela Cadastro) 
				JButton salvar = new JButton("Salvar");
				salvar.setFont(new Font("Calibri", Font.BOLD, 20));
				salvar.setBounds(350, 600, 100, 30);
				pgcad.add(salvar);
				salvar.addActionListener( new  ActionListener(){  
				    public void  actionPerformed(ActionEvent e, String observacao, String endereco, String date, String nome){
				   
				   Paciente paciente = new Paciente( nome, date, endereco, observacao, 0);
				    	

				   String nvNome = (String)txtnome.getText();
				   paciente.setNome(nome);
				   
				   String nvDate = (String)txtdate.getText();
				   paciente.setDate(date);
				   
				   String nvEndereco = (String)txtendereco.getText();
				   paciente.setEndereco(endereco);
				   
				   String nvObservacao = (String)txtobservacao.getText();
				   paciente.setObservacao(observacao);
				   
				   listaPaciente.add(paciente);
				   paciente.getId();
				   int contadorDeId = 1;
				   paciente.id = contadorDeId++;
				   
				   
				    
				   
				    	
				    	JFrame confirma = new JFrame("Confirmação de Cadastro");
				    	confirma.setVisible(true);
				    	JOptionPane.showMessageDialog(null, "Cadastro Feito com Sucesso!");
				    	pgcad.setVisible(false);
				    	janela.setVisible(true);
				    }

					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						
					}
				});

				//Bot�o de 'Voltar' da pagina cadastro
				JButton voltar = new JButton("Voltar");
				voltar.setFont(new Font("Calibri", Font.BOLD, 20));
				voltar.setBounds(0, 0, 100, 30);
				pgcad.add(voltar);
				voltar.addActionListener( new  ActionListener(){  
				    public void  actionPerformed(ActionEvent e){
				    	pgcad.setVisible(false);
				    	janela.setVisible(true);
				    }
				});
		    }	            
	});
		
		//Janela de Editar
		edt.addActionListener( new  ActionListener(){  
		    public void  actionPerformed(ActionEvent e){   
		    	janela.setVisible(false);  
		    	JFrame pgedt = new JFrame("Editar Cadastro de Pacientes");
				pgedt.setSize(700, 700);
				pgedt.getContentPane().setBackground(new Color(100, 50, 50));
				pgedt.setLayout(null);
				pgedt.setVisible(true);
				
				//Leitura do Id
				JTextField txtEdtId = new JTextField(30);
				JLabel labelEdtId = new JLabel("Digite o ID: ");
				labelEdtId.setFont(new Font("Calibri", Font.BOLD, 30));
				labelEdtId.setForeground(Color.white);
				labelEdtId.setBounds(10, 100, 300, 30);
				txtEdtId.setBounds(200, 100, 100, 30);
				pgedt.add(txtEdtId);
				pgedt.add(labelEdtId);
				
				//Text area
				JTextArea txtPacId = new JTextArea(10, 10);
				txtPacId.setFont(new Font("Calibri", Font.BOLD, 30));
				txtPacId.setBounds(200, 250, 300, 300);
				pgedt.add(txtPacId);
				
				//botao Pesquisar
				JButton jbPesquisar = new JButton("Pesquisar");
				jbPesquisar.setFont(new Font("Calibri", Font.BOLD, 20));
				jbPesquisar.setBounds(350, 100, 150, 30);
				pgedt.add(jbPesquisar);
				jbPesquisar.addActionListener( new  ActionListener(){  
				    public void  actionPerformed(ActionEvent e){
				    	
				    }
				});
				
				
				//Botao Salvar edicao
				JButton jbsalvarEdt = new JButton("Salvar");
				jbsalvarEdt.setFont(new Font("Calibri", Font.BOLD, 20));
				jbsalvarEdt.setBounds(350, 600, 100, 30);
				pgedt.add(jbsalvarEdt);
				jbsalvarEdt.addActionListener( new  ActionListener(){  
				    public void  actionPerformed(ActionEvent e){
				    	JOptionPane.showMessageDialog(null, "Cadastro Editado com Sucesso!");
				    	pgedt.setVisible(false);
				    	janela.setVisible(true);
				    
				    }
				});
								
				//Bot�o de Voltar da pagina editar
				JButton voltar = new JButton("Voltar");
				voltar.setFont(new Font("Calibri", Font.BOLD, 20));
				voltar.setBounds(0, 0, 100, 30);
				pgedt.add(voltar);
				voltar.addActionListener( new  ActionListener(){  
				    public void  actionPerformed(ActionEvent e){
				    	pgedt.setVisible(false);
				    	janela.setVisible(true);
				    	   
				    
				    }
				});
		    }	            
	});
		//Janela de Pesuisar
		pes.addActionListener( new  ActionListener(){  
		    public void  actionPerformed(ActionEvent e){   
		    	janela.setVisible(false);
		    	JFrame pgpes = new JFrame("pesquisar Pacientes");
				pgpes.setSize(700, 700);
				pgpes.getContentPane().setBackground(new Color(100, 50, 50));
				pgpes.setLayout(null);
				pgpes.setVisible(true);
				
				//Leitura do Id
				JTextField txtEdtId = new JTextField(30);
				JLabel labelEdtId = new JLabel("Digite o ID: ");
				labelEdtId.setFont(new Font("Calibri", Font.BOLD, 30));
				labelEdtId.setForeground(Color.white);
				labelEdtId.setBounds(10, 100, 300, 30);
				txtEdtId.setBounds(200, 100, 100, 30);
				pgpes.add(txtEdtId);
				pgpes.add(labelEdtId);
				
				//Text area
				JTextArea txtPacId = new JTextArea(10, 10);
				txtPacId.setFont(new Font("Calibri", Font.BOLD, 30));
				txtPacId.setBounds(200, 250, 300, 300);
				pgpes.add(txtPacId);
				
				//botao Pesquisar
				JButton jbPesquisar = new JButton("Pesquisar");
				jbPesquisar.setFont(new Font("Calibri", Font.BOLD, 20));
				jbPesquisar.setBounds(350, 100, 150, 30);
				pgpes.add(jbPesquisar);
				jbPesquisar.addActionListener( new  ActionListener(){  
				    public void  actionPerformed(ActionEvent e){
				    	
				    }
				});
				
				//Bot�o de Voltar da pagina pesquisa
				JButton voltar = new JButton("Voltar");
				voltar.setFont(new Font("Calibri", Font.BOLD, 20));
				voltar.setBounds(0, 0, 100, 30);
				pgpes.add(voltar);
				voltar.addActionListener( new  ActionListener(){  
				    public void  actionPerformed(ActionEvent e){
				    	pgpes.setVisible(false);
				    	janela.setVisible(true);
				    }
				});
		    }	            
	});
		
		rem.addActionListener( new  ActionListener(){  
		    public void  actionPerformed(ActionEvent e){   
		    	janela.setVisible(false);
		    	JFrame pgrem = new JFrame("Remover Cadastro Pacientes");
				pgrem.setSize(700, 700);
				pgrem.getContentPane().setBackground(new Color(100, 50, 50));
				pgrem.setLayout(null);
				pgrem.setVisible(true);
				
				//Bot�o de Voltar da pagina remover
				JButton voltar = new JButton("Voltar");
				voltar.setFont(new Font("Calibri", Font.BOLD, 20));
				voltar.setBounds(0, 0, 100, 30);
				pgrem.add(voltar);
				voltar.addActionListener( new  ActionListener(){  
				    public void  actionPerformed(ActionEvent e){
				    	pgrem.setVisible(false);
				    	janela.setVisible(true);
				    }
				});
				
		    }	            
	});
	
		}  
		    }


