package controleCliente;

public class Paciente {

	private String nome;
	private String endereco;
	private String date;
	private String observacao;
	protected int id;
	
	
	
	public Paciente(String nome, String endereco, String date, String observacao, int id) {
		this.nome = nome;
		this.endereco = endereco;
		this.date = date;
		this.observacao = observacao;
		this.id = id;
		
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getObservacao() {
		return observacao;
	}
	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = (int) id;
	}
	
	

}

